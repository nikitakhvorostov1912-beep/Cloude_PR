@echo off
chcp 65001 >nul

set "LOGFILE=%~dp0start_debug.log"
echo === Debug Start: %date% %time% === > "%LOGFILE%"

echo Шаг 1: Определение путей >> "%LOGFILE%"
set "SCRIPT_DIR=%~dp0"
set "BACKEND_DIR=%SCRIPT_DIR%backend"
set "FRONTEND_DIR=%SCRIPT_DIR%frontend"
set "VENV_PYTHON=%BACKEND_DIR%\.venv\Scripts\python.exe"
set "NODE_DIR=C:\tools\nodejs\node-v22.14.0-win-x64"

echo   SCRIPT_DIR=%SCRIPT_DIR% >> "%LOGFILE%"
echo   BACKEND_DIR=%BACKEND_DIR% >> "%LOGFILE%"
echo   FRONTEND_DIR=%FRONTEND_DIR% >> "%LOGFILE%"
echo   VENV_PYTHON=%VENV_PYTHON% >> "%LOGFILE%"
echo   NODE_DIR=%NODE_DIR% >> "%LOGFILE%"

echo Шаг 2: Проверка файлов >> "%LOGFILE%"
if exist "%VENV_PYTHON%" (
    echo   VENV Python: НАЙДЕН >> "%LOGFILE%"
) else (
    echo   VENV Python: НЕ НАЙДЕН >> "%LOGFILE%"
)

if exist "%NODE_DIR%\node.exe" (
    echo   Node.js: НАЙДЕН >> "%LOGFILE%"
) else (
    echo   Node.js: НЕ НАЙДЕН >> "%LOGFILE%"
)

if exist "%FRONTEND_DIR%\node_modules" (
    echo   node_modules: НАЙДЕН >> "%LOGFILE%"
) else (
    echo   node_modules: НЕ НАЙДЕН >> "%LOGFILE%"
)

echo Шаг 3: Добавление Node в PATH >> "%LOGFILE%"
set "PATH=%NODE_DIR%;%PATH%"

echo Шаг 4: Запуск Backend >> "%LOGFILE%"
start "Survey-Backend" cmd /k "cd /d %BACKEND_DIR% && %VENV_PYTHON% -m uvicorn main:app --host 0.0.0.0 --port 8000 --reload"
echo   Backend start: errorlevel=%errorlevel% >> "%LOGFILE%"

echo Шаг 5: Запуск Frontend >> "%LOGFILE%"
start "Survey-Frontend" cmd /k "cd /d %FRONTEND_DIR% && npm run dev"
echo   Frontend start: errorlevel=%errorlevel% >> "%LOGFILE%"

echo Шаг 6: Ожидание >> "%LOGFILE%"
echo === Debug End: %date% %time% === >> "%LOGFILE%"

echo.
echo Диагностика записана в: %LOGFILE%
echo.
echo Открываю лог...
start notepad "%LOGFILE%"
pause
