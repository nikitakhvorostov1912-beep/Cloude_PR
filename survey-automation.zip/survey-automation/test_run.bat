@echo off
echo TEST START > "%~dp0test_run.log"
echo Path: %~dp0 >> "%~dp0test_run.log"
echo OK >> "%~dp0test_run.log"
echo Тест прошёл! Нажмите любую клавишу...
pause
